// js/admin.js — Logic หน้า Admin

let rejectTargetId = null;

document.addEventListener('DOMContentLoaded', () => {
  Auth.requireRole('admin');
  refreshAll();
});

function refreshAll() {
  renderSummaryStats();
  renderStationCards();
  renderPending();
  renderAll();
  renderSummaryTab();
}

// ===== SUMMARY STATS HEADER =====
function renderSummaryStats() {
  const all = Store.getAll();
  const approved = all.filter(r => r.status === 'approved');
  const pending = all.filter(r => r.status === 'pending');
  const totalWeight = approved.reduce((s, r) => s + parseFloat(r.weight || 0), 0);
  const totalAmount = approved.reduce((s, r) => s + parseFloat(r.amount || 0), 0);

  document.getElementById('summaryStats').innerHTML = `
    <div class="stat-card">
      <div class="stat-icon blue">📋</div>
      <div class="stat-info">
        <div class="stat-label">รายการทั้งหมด</div>
        <div class="stat-value">${all.length} <span class="stat-unit">รายการ</span></div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon orange">⏳</div>
      <div class="stat-info">
        <div class="stat-label">รอตรวจสอบ</div>
        <div class="stat-value">${pending.length} <span class="stat-unit">รายการ</span></div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green">⚖️</div>
      <div class="stat-info">
        <div class="stat-label">น้ำหนักรวม (อนุมัติ)</div>
        <div class="stat-value">${formatNumber(totalWeight)} <span class="stat-unit">กก.</span></div>
      </div>
    </div>
  `;
}

// ===== STATION SUMMARY CARDS =====
function renderStationCards() {
  const summary = Store.getSummary();
  document.getElementById('stationSummaryCards').innerHTML = Object.entries(STATIONS).map(([sid, st]) => {
    const s = summary[sid];
    return `
      <div class="stat-card" style="flex-direction:column;align-items:flex-start;gap:10px;">
        <div class="flex-between" style="width:100%">
          <div class="flex-center gap-2">
            <div class="stat-icon green" style="width:40px;height:40px;font-size:1.3rem;">${st.icon}</div>
            <div>
              <div style="font-family:'Kanit',sans-serif;font-weight:600;color:var(--primary-dark)">${st.name}</div>
              <div style="font-size:0.78rem;color:var(--text-muted)">${st.location}</div>
            </div>
          </div>
        </div>
        <div style="width:100%;display:grid;grid-template-columns:1fr 1fr;gap:8px;">
          <div style="background:#f0f9f0;border-radius:8px;padding:8px 10px;">
            <div style="font-size:0.75rem;color:var(--text-muted)">รายการ</div>
            <div style="font-family:'Kanit',sans-serif;font-weight:700;font-size:1.1rem">${s.count}</div>
          </div>
          <div style="background:#fff8e6;border-radius:8px;padding:8px 10px;">
            <div style="font-size:0.75rem;color:var(--text-muted)">น้ำหนัก</div>
            <div style="font-family:'Kanit',sans-serif;font-weight:700;font-size:1.1rem">${formatNumber(s.totalWeight)}</div>
          </div>
          <div style="background:#e8f5e8;border-radius:8px;padding:8px 10px;grid-column:span 2;">
            <div style="font-size:0.75rem;color:var(--text-muted)">ยอดเงินรวม (บาท)</div>
            <div style="font-family:'Kanit',sans-serif;font-weight:700;font-size:1.2rem;color:var(--primary)">${formatNumber(s.totalAmount)}</div>
          </div>
        </div>
        <button class="btn btn-outline btn-sm" style="width:100%" onclick="exportStation('${sid}')">📥 Export ${st.name}</button>
      </div>
    `;
  }).join('');
}

// ===== PENDING TAB =====
function renderPending() {
  const pending = Store.getPending().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  document.getElementById('pendingCount').textContent = pending.length;

  const tbody = document.getElementById('pendingBody');
  if (pending.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11"><div class="empty-state"><div class="icon">✅</div><p>ไม่มีรายการรอตรวจสอบ</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = pending.map(r => `
    <tr>
      <td><code style="font-size:0.78rem;color:#666">${r.id}</code></td>
      <td>${STATIONS[r.stationId]?.name || r.stationId}</td>
      <td>${r.purchaseDate}</td>
      <td>${r.farmerName}</td>
      <td>${r.truckPlate || '-'}</td>
      <td class="text-right">${formatNumber(r.weight)}</td>
      <td class="text-right">${formatNumber(r.pricePerKg)}</td>
      <td class="text-right fw-bold">${formatNumber(r.amount)}</td>
      <td>${r.note || '-'}</td>
      <td style="white-space:nowrap">${formatDateTime(r.createdAt)}</td>
      <td>
        <div class="btn-group">
          <button class="btn btn-primary btn-sm" onclick="approve('${r.id}')">✅</button>
          <button class="btn btn-danger btn-sm" onclick="openReject('${r.id}')">❌</button>
        </div>
      </td>
    </tr>
  `).join('');
}

// ===== ALL TAB =====
function renderAll() {
  const filterStation = document.getElementById('filterStation').value;
  const filterStatus = document.getElementById('filterStatus').value;
  let records = Store.getAll().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  if (filterStation) records = records.filter(r => r.stationId === filterStation);
  if (filterStatus) records = records.filter(r => r.status === filterStatus);

  const tbody = document.getElementById('allBody');
  if (records.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11"><div class="empty-state"><div class="icon">📭</div><p>ไม่พบรายการ</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = records.map(r => `
    <tr>
      <td><code style="font-size:0.78rem;color:#666">${r.id}</code></td>
      <td>${STATIONS[r.stationId]?.name || r.stationId}</td>
      <td>${r.purchaseDate}</td>
      <td>${r.farmerName}</td>
      <td>${r.truckPlate || '-'}</td>
      <td class="text-right">${formatNumber(r.weight)}</td>
      <td class="text-right">${formatNumber(r.pricePerKg)}</td>
      <td class="text-right fw-bold">${formatNumber(r.amount)}</td>
      <td>${statusBadge(r.status)}</td>
      <td style="white-space:nowrap">${formatDateTime(r.createdAt)}</td>
      <td>
        ${r.status === 'pending' ? `
          <div class="btn-group">
            <button class="btn btn-primary btn-sm" onclick="approve('${r.id}')">✅</button>
            <button class="btn btn-danger btn-sm" onclick="openReject('${r.id}')">❌</button>
          </div>` : ''}
      </td>
    </tr>
  `).join('');
}

// ===== SUMMARY TAB =====
function renderSummaryTab() {
  const summary = Store.getSummary();
  const all = Store.getAll().filter(r => r.status === 'approved');
  const grandWeight = all.reduce((s, r) => s + parseFloat(r.weight || 0), 0);
  const grandAmount = all.reduce((s, r) => s + parseFloat(r.amount || 0), 0);

  let html = `
    <div class="card mb-3">
      <div class="card-header">
        <span class="card-title">📊 สรุปรวมทุกลาน (รายการที่อนุมัติ)</span>
        <button class="btn btn-accent btn-sm" onclick="exportAll()">📥 Export สรุปทั้งหมด</button>
      </div>
      <div class="card-body" style="padding:0;">
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ลานปาล์ม</th>
                <th>พื้นที่</th>
                <th class="text-right">จำนวนรายการ</th>
                <th class="text-right">น้ำหนักรวม (กก.)</th>
                <th class="text-right">ยอดเงินรวม (บาท)</th>
                <th class="text-right">ราคาเฉลี่ย/กก.</th>
              </tr>
            </thead>
            <tbody>
  `;

  Object.entries(STATIONS).forEach(([sid, st]) => {
    const s = summary[sid];
    const avgPrice = s.totalWeight > 0 ? s.totalAmount / s.totalWeight : 0;
    html += `
      <tr>
        <td>${st.icon} ${st.name}</td>
        <td>${st.location}</td>
        <td class="text-right">${s.count}</td>
        <td class="text-right">${formatNumber(s.totalWeight)}</td>
        <td class="text-right fw-bold">${formatNumber(s.totalAmount)}</td>
        <td class="text-right">${formatNumber(avgPrice)}</td>
      </tr>
    `;
  });

  const grandAvg = grandWeight > 0 ? grandAmount / grandWeight : 0;
  html += `
            <tr style="background:#f0f9f0;font-weight:700;border-top:2px solid var(--primary)">
              <td colspan="2" style="font-family:'Kanit',sans-serif">🌴 รวมทั้งหมด</td>
              <td class="text-right">${all.length}</td>
              <td class="text-right">${formatNumber(grandWeight)}</td>
              <td class="text-right" style="color:var(--primary)">${formatNumber(grandAmount)}</td>
              <td class="text-right">${formatNumber(grandAvg)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  `;

  // Per-station details
  html += `<div class="grid-3">`;
  Object.entries(STATIONS).forEach(([sid, st]) => {
    const records = Store.getByStation(sid).filter(r => r.status === 'approved').slice(0, 5);
    html += `
      <div class="card">
        <div class="card-header">
          <span class="card-title">${st.icon} ${st.name}</span>
          <button class="btn btn-outline btn-sm" onclick="exportStation('${sid}')">📥 Export</button>
        </div>
        <div class="card-body" style="padding:0;">
          <table>
            <thead><tr><th>วันที่</th><th>เกษตรกร</th><th class="text-right">น้ำหนัก</th></tr></thead>
            <tbody>
              ${records.length === 0
                ? `<tr><td colspan="3"><div class="empty-state" style="padding:20px;"><p>ยังไม่มีข้อมูล</p></div></td></tr>`
                : records.map(r => `<tr><td>${r.purchaseDate}</td><td>${r.farmerName}</td><td class="text-right">${formatNumber(r.weight)}</td></tr>`).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  });
  html += `</div>`;

  document.getElementById('summaryContent').innerHTML = html;
}

// ===== APPROVE / REJECT =====
function approve(id) {
  Store.update(id, { status: 'approved' });
  refreshAll();
}

function approveAll() {
  const pending = Store.getPending();
  if (pending.length === 0) { alert('ไม่มีรายการรอตรวจสอบ'); return; }
  if (!confirm(`อนุมัติทั้งหมด ${pending.length} รายการ?`)) return;
  pending.forEach(r => Store.update(r.id, { status: 'approved' }));
  refreshAll();
}

function openReject(id) {
  rejectTargetId = id;
  document.getElementById('rejectReason').value = '';
  document.getElementById('rejectModal').style.display = 'flex';
}

function closeRejectModal() {
  rejectTargetId = null;
  document.getElementById('rejectModal').style.display = 'none';
}

function confirmReject() {
  if (!rejectTargetId) return;
  const reason = document.getElementById('rejectReason').value.trim();
  Store.update(rejectTargetId, { status: 'rejected', rejectReason: reason });
  closeRejectModal();
  refreshAll();
}

// ===== EXPORT =====
function exportAll() {
  exportToExcel(Store.getAll(), 'palm_ALL');
}

function exportFiltered() {
  const filterStation = document.getElementById('filterStation').value;
  const filterStatus = document.getElementById('filterStatus').value;
  let records = Store.getAll();
  if (filterStation) records = records.filter(r => r.stationId === filterStation);
  if (filterStatus) records = records.filter(r => r.status === filterStatus);
  const label = (filterStation ? STATIONS[filterStation]?.name : 'ALL') + (filterStatus ? '_' + filterStatus : '');
  exportToExcel(records, 'palm_' + label);
}

function exportStation(sid) {
  const records = Store.getByStation(sid);
  exportToExcel(records, 'palm_' + sid);
}

// ===== TABS =====
function switchTab(tabId, btn) {
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(tabId).classList.add('active');
  btn.classList.add('active');
  if (tabId === 'tabSummary') renderSummaryTab();
  if (tabId === 'tabAll') renderAll();
  if (tabId === 'tabPending') renderPending();
}
