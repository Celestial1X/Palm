// js/login.js — Logic สำหรับหน้า Login

document.addEventListener('DOMContentLoaded', () => {
  // ถ้า login แล้วให้ redirect ทันที
  const user = Auth.current();
  if (user) {
    redirect(user);
  }

  // กด Enter เพื่อ login
  document.getElementById('password').addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
  document.getElementById('userId').addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('password').focus();
  });
});

function doLogin() {
  const userId = document.getElementById('userId').value.trim();
  const password = document.getElementById('password').value;
  const alertBox = document.getElementById('alertBox');

  if (!userId || !password) {
    showAlert(alertBox, 'warning', '⚠️ กรุณากรอกชื่อผู้ใช้และรหัสผ่าน');
    return;
  }

  const user = Auth.login(userId, password);
  if (user) {
    showAlert(alertBox, 'success', '✅ เข้าสู่ระบบสำเร็จ กำลังโหลด...');
    setTimeout(() => redirect(user), 800);
  } else {
    showAlert(alertBox, 'danger', '❌ ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
    document.getElementById('password').value = '';
    document.getElementById('password').focus();
  }
}

function quickLogin(userId, password) {
  document.getElementById('userId').value = userId;
  document.getElementById('password').value = password;
  doLogin();
}

function redirect(user) {
  if (user.role === 'admin') {
    window.location.href = 'pages/admin.html';
  } else {
    window.location.href = 'pages/station.html';
  }
}
