// js/station.js — Logic หน้าลาน (User ลาน)

let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
  currentUser = Auth.requireRole('station');
  initPage();
});

function initPage() {
  const station = STATIONS[currentUser.station];

  // Navbar
  document.getElementById('navStationName').textContent = station.name;
  document.getElementById('navRoleBadge').textContent = 'ลาน';

  // Header
  document.getElementById('stationTitle').textContent = station.icon + ' ' + station.name;
  document.getElementById('stationSubtitle').textContent = 'บันทึกข้อมูลรับซื้อผลปาล์มน้ำมัน — ' + station.location;

  // Form defaults
  document.getElementById('stationDisplay').value = station.name;
  document.getElementById('purchaseDate').value = new Date().toISOString().slice(0, 10);

  updateStats();
  renderHistory();
}

function updateStats() {
  const records = Store.getByStation(currentUser.station);
  const approved = records.filter(r => r.status === 'approved');
  const pending = records.filter(r => r.status === 'pending');
  const totalWeight = approved.reduce((s, r) => s + parseFloat(r.weight || 0), 0);

  document.getElementById('statTotal').textContent = records.length;
  document.getElementById('statPending').textContent = pending.length;
  document.getElementById('statWeight').textContent = formatNumber(totalWeight);
}

function calcAmount() {
  const w = parseFloat(document.getElementById('weight').value) || 0;
  const p = parseFloat(document.getElementById('pricePerKg').value) || 0;
  const amt = w * p;
  document.getElementById('amount').value = amt > 0 ? formatNumber(amt) : '';
}

function submitRecord() {
  const alertBox = document.getElementById('formAlert');

  const purchaseDate = document.getElementById('purchaseDate').value;
  const farmerName = document.getElementById('farmerName').value.trim();
  const farmerPhone = document.getElementById('farmerPhone').value.trim();
  const truckPlate = document.getElementById('truckPlate').value.trim();
  const weight = parseFloat(document.getElementById('weight').value);
  const pricePerKg = parseFloat(document.getElementById('pricePerKg').value);
  const note = document.getElementById('note').value.trim();

  if (!purchaseDate) { showAlert(alertBox, 'warning', '⚠️ กรุณาเลือกวันที่รับซื้อ'); return; }
  if (!farmerName) { showAlert(alertBox, 'warning', '⚠️ กรุณากรอกชื่อเกษตรกร'); return; }
  if (!weight || weight <= 0) { showAlert(alertBox, 'warning', '⚠️ กรุณากรอกน้ำหนัก'); return; }
  if (!pricePerKg || pricePerKg <= 0) { showAlert(alertBox, 'warning', '⚠️ กรุณากรอกราคา/กก.'); return; }

  const amount = weight * pricePerKg;

  Store.add({
    stationId: currentUser.station,
    stationName: STATIONS[currentUser.station].name,
    submittedBy: currentUser.id,
    purchaseDate,
    farmerName,
    farmerPhone,
    truckPlate,
    weight,
    pricePerKg,
    amount,
    note,
  });

  showAlert(alertBox, 'success', '✅ บันทึกข้อมูลสำเร็จ รอการตรวจสอบจาก Admin');
  resetForm();
  updateStats();
  renderHistory();
}

function resetForm() {
  document.getElementById('farmerName').value = '';
  document.getElementById('farmerPhone').value = '';
  document.getElementById('truckPlate').value = '';
  document.getElementById('weight').value = '';
  document.getElementById('pricePerKg').value = '';
  document.getElementById('amount').value = '';
  document.getElementById('note').value = '';
  document.getElementById('purchaseDate').value = new Date().toISOString().slice(0, 10);
}

function renderHistory() {
  const records = Store.getByStation(currentUser.station)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const tbody = document.getElementById('historyBody');

  if (records.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10"><div class="empty-state"><div class="icon">📭</div><p>ยังไม่มีรายการ</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = records.map(r => `
    <tr>
      <td><code style="font-size:0.78rem;color:#666">${r.id}</code></td>
      <td>${r.purchaseDate}</td>
      <td>${r.farmerName}</td>
      <td>${r.truckPlate || '-'}</td>
      <td class="text-right">${formatNumber(r.weight)}</td>
      <td class="text-right">${formatNumber(r.pricePerKg)}</td>
      <td class="text-right fw-bold">${formatNumber(r.amount)}</td>
      <td>${statusBadge(r.status)}</td>
      <td style="white-space:nowrap">${formatDateTime(r.createdAt)}</td>
      <td>
        ${r.status === 'pending' ? `<button class="btn btn-danger btn-sm" onclick="deleteRecord('${r.id}')">🗑</button>` : ''}
      </td>
    </tr>
  `).join('');
}

function deleteRecord(id) {
  if (!confirm('ยืนยันการลบรายการนี้?')) return;
  Store.delete(id);
  updateStats();
  renderHistory();
}

function exportMyData() {
  const records = Store.getByStation(currentUser.station);
  const station = STATIONS[currentUser.station];
  exportToExcel(records, 'palm_' + currentUser.station);
}

function switchTab(tabId, btn) {
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(tabId).classList.add('active');
  btn.classList.add('active');
  if (tabId === 'tabHistory') renderHistory();
}
