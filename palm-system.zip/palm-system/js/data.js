// ===== PALM STATION MANAGEMENT SYSTEM =====
// js/data.js — ข้อมูลกลาง, การยืนยันตัวตน, และ Storage

const USERS = [
  { id: 'admin', name: 'ผู้ดูแลระบบ', role: 'admin', password: 'admin1234', station: null },
  { id: 'station1', name: 'ลานปาล์ม A', role: 'station', password: 'station1', station: 'ST001' },
  { id: 'station2', name: 'ลานปาล์ม B', role: 'station', password: 'station2', station: 'ST002' },
  { id: 'station3', name: 'ลานปาล์ม C', role: 'station', password: 'station3', station: 'ST003' },
];

const STATIONS = {
  ST001: { name: 'ลานปาล์ม A', location: 'อำเภอเมือง', icon: '🌿' },
  ST002: { name: 'ลานปาล์ม B', location: 'อำเภอท่าเรือ', icon: '🌱' },
  ST003: { name: 'ลานปาล์ม C', location: 'อำเภอบ้านนา', icon: '🍃' },
};

// ===== AUTH =====
const Auth = {
  login(userId, password) {
    const user = USERS.find(u => u.id === userId && u.password === password);
    if (user) {
      localStorage.setItem('palmUser', JSON.stringify(user));
      return user;
    }
    return null;
  },
  logout() {
    localStorage.removeItem('palmUser');
    window.location.href = 'index.html';
  },
  current() {
    const d = localStorage.getItem('palmUser');
    return d ? JSON.parse(d) : null;
  },
  requireAuth() {
    const user = this.current();
    if (!user) window.location.href = 'index.html';
    return user;
  },
  requireRole(role) {
    const user = this.requireAuth();
    if (user.role !== role) {
      alert('คุณไม่มีสิทธิ์เข้าถึงหน้านี้');
      window.location.href = user.role === 'admin' ? 'pages/admin.html' : 'pages/station.html';
    }
    return user;
  }
};

// ===== DATA STORE =====
const Store = {
  KEY: 'palmData_v1',
  COUNTER_KEY: 'palmCounter_v1',

  _nextId() {
    let c = parseInt(localStorage.getItem(this.COUNTER_KEY) || '0') + 1;
    localStorage.setItem(this.COUNTER_KEY, c);
    return 'REC' + String(c).padStart(5, '0');
  },

  load() {
    const d = localStorage.getItem(this.KEY);
    return d ? JSON.parse(d) : [];
  },

  save(records) {
    localStorage.setItem(this.KEY, JSON.stringify(records));
  },

  add(record) {
    const records = this.load();
    const newRec = {
      ...record,
      id: this._nextId(),
      createdAt: new Date().toISOString(),
      status: 'pending',
    };
    records.push(newRec);
    this.save(records);
    return newRec;
  },

  update(id, updates) {
    const records = this.load();
    const idx = records.findIndex(r => r.id === id);
    if (idx !== -1) {
      records[idx] = { ...records[idx], ...updates, updatedAt: new Date().toISOString() };
      this.save(records);
      return records[idx];
    }
    return null;
  },

  delete(id) {
    const records = this.load();
    const filtered = records.filter(r => r.id !== id);
    this.save(filtered);
  },

  getByStation(stationId) {
    return this.load().filter(r => r.stationId === stationId);
  },

  getAll() {
    return this.load();
  },

  // สรุปรวมทุกลาน
  getSummary() {
    const records = this.load().filter(r => r.status === 'approved');
    const summary = {};
    Object.keys(STATIONS).forEach(sid => {
      summary[sid] = { count: 0, totalWeight: 0, totalAmount: 0 };
    });
    records.forEach(r => {
      if (summary[r.stationId]) {
        summary[r.stationId].count++;
        summary[r.stationId].totalWeight += parseFloat(r.weight) || 0;
        summary[r.stationId].totalAmount += parseFloat(r.amount) || 0;
      }
    });
    return summary;
  },

  // รายการรอการอนุมัติ
  getPending() {
    return this.load().filter(r => r.status === 'pending');
  },
};

// ===== HELPERS =====
function formatDate(isoStr) {
  if (!isoStr) return '-';
  const d = new Date(isoStr);
  return d.toLocaleDateString('th-TH', { year: 'numeric', month: '2-digit', day: '2-digit' });
}

function formatDateTime(isoStr) {
  if (!isoStr) return '-';
  const d = new Date(isoStr);
  return d.toLocaleDateString('th-TH') + ' ' + d.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' });
}

function formatNumber(n) {
  return parseFloat(n || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatWeight(n) {
  return parseFloat(n || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' กก.';
}

function showAlert(el, type, msg) {
  el.className = 'alert alert-' + type + ' show';
  el.innerHTML = msg;
  setTimeout(() => { el.className = 'alert'; }, 4000);
}

function statusBadge(status) {
  const map = { pending: ['badge-pending', '⏳ รอตรวจสอบ'], approved: ['badge-approved', '✅ อนุมัติ'], rejected: ['badge-rejected', '❌ ปฏิเสธ'] };
  const [cls, label] = map[status] || ['', status];
  return `<span class="badge-status ${cls}">${label}</span>`;
}

// ===== EXPORT EXCEL =====
function exportToExcel(records, filename) {
  if (!records || records.length === 0) {
    alert('ไม่มีข้อมูลสำหรับ Export');
    return;
  }

  const headers = ['รหัส', 'ลาน', 'วันที่รับซื้อ', 'ชื่อเกษตรกร', 'เบอร์โทร', 'ทะเบียนรถ', 'น้ำหนัก (กก.)', 'ราคา/กก.', 'จำนวนเงิน (บาท)', 'หมายเหตุ', 'สถานะ', 'วันที่บันทึก'];

  const rows = records.map(r => [
    r.id,
    STATIONS[r.stationId] ? STATIONS[r.stationId].name : r.stationId,
    r.purchaseDate,
    r.farmerName,
    r.farmerPhone,
    r.truckPlate,
    parseFloat(r.weight || 0),
    parseFloat(r.pricePerKg || 0),
    parseFloat(r.amount || 0),
    r.note || '',
    r.status === 'approved' ? 'อนุมัติ' : r.status === 'rejected' ? 'ปฏิเสธ' : 'รอตรวจสอบ',
    formatDateTime(r.createdAt)
  ]);

  // Build CSV then convert to Excel-compatible UTF-8 BOM
  const BOM = '\uFEFF';
  const csvContent = [headers, ...rows].map(row =>
    row.map(cell => {
      const s = String(cell ?? '');
      return s.includes(',') || s.includes('"') || s.includes('\n')
        ? '"' + s.replace(/"/g, '""') + '"'
        : s;
    }).join(',')
  ).join('\n');

  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename + '_' + new Date().toISOString().slice(0, 10) + '.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
